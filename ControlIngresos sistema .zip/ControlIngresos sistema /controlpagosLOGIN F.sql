-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-04-2018 a las 15:52:29
-- Versión del servidor: 10.1.30-MariaDB
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `controlpagos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_matricula`
--

CREATE TABLE `detalle_matricula` (
  `id_detallematricula` int(11) NOT NULL,
  `id_matricula` int(11) NOT NULL,
  `nro_recibo` varchar(7) NOT NULL,
  `monto_matricula` double NOT NULL,
  `fecha_matricula` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalle_matricula`
--

INSERT INTO `detalle_matricula` (`id_detallematricula`, `id_matricula`, `nro_recibo`, `monto_matricula`, `fecha_matricula`) VALUES
(1, 1, '0012405', 100, '2018-01-02'),
(2, 2, '0012288', 100, '2018-02-04'),
(3, 3, '0012503', 100, '2018-02-12'),
(4, 4, '0012381', 120, '2018-02-22'),
(5, 5, '0012445', 80, '2018-01-09'),
(6, 6, '0012456', 150, '2018-01-10'),
(7, 7, '0012457', 150, '2018-01-17'),
(8, 8, '0012458', 150, '2018-01-18'),
(9, 9, '0012569', 150, '2018-02-01'),
(10, 10, '0012460', 150, '2018-02-02'),
(12, 12, '0012461', 150, '2018-02-02'),
(13, 13, '0012462', 150, '2018-03-02'),
(14, 14, '0012463', 50, '2018-03-05');

--
-- Disparadores `detalle_matricula`
--
DELIMITER $$
CREATE TRIGGER `deleteDetalleMatricula` AFTER DELETE ON `detalle_matricula` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible-old.monto_matricula
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertDetalleMatricula` AFTER INSERT ON `detalle_matricula` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible+new.monto_matricula
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateDetalleMatricula` AFTER UPDATE ON `detalle_matricula` FOR EACH ROW BEGIN
    IF new.monto_matricula>old.monto_matricula THEN
        UPDATE saldo_actual
        SET monto_disponible=monto_disponible+(new.monto_matricula-old.monto_matricula);
        UPDATE matricula
        SET pendiente_matricula=pendiente_matricula-(new.monto_matricula-old.monto_matricula) 
        where id_matricula=new.id_matricula;
    ELSE
        UPDATE saldo_actual
        SET monto_disponible=monto_disponible-(old.monto_matricula-new.monto_matricula);
		UPDATE matricula
        SET pendiente_matricula=pendiente_matricula+(old.monto_matricula-new.monto_matricula)
        where id_matricula=new.id_matricula;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE `estudiante` (
  `dni_estudiante` varchar(8) NOT NULL,
  `nombres_estudiante` varchar(50) NOT NULL,
  `apellidos_estudiante` varchar(50) NOT NULL,
  `nombres_padre` varchar(80) DEFAULT NULL,
  `nombres_madre` varchar(80) DEFAULT NULL,
  `telefono` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`dni_estudiante`, `nombres_estudiante`, `apellidos_estudiante`, `nombres_padre`, `nombres_madre`, `telefono`) VALUES
('61450153', 'NOELIA VANESA', 'BALLON SAYAGO', 'BALLON ALVARADO WILFREDO', 'SAYAGO MARIÑO IRMA', '983619939'),
('61779274', 'AZUMI DHI', 'CHAVEZ DIAS', 'CHAVEZ HUAMAN GREGORIO', 'DIAS CHUMBILE YANETT', '966888558'),
('61859475', 'SONYU MARIO', 'SANCHES PELAES', 'SANCHEZ DAMIAN MARIO', 'PELAES MEJIA GLADYS', '958720944'),
('61859547', 'KEYLA NASHIRA', 'MENDOZA MOREANO', 'MENDOZA SOTO EDWIN', 'MOREANO MEDINA SHEYLA', '991988454'),
('62050041', 'BENJAMIN JOSE', 'PALOMINO LOPEZ', 'ASURIN SALAZAR VICTOR AGUSTO', 'PALOMINO LOPEZ REYNA ELIZABETH', NULL),
('62053770', 'DIEGO', 'ARCOS TINTAYA', 'ARCOS MANSILLA ROTMER', 'TINTAYA CARBAJAL MARILU', '941091063'),
('62462904', 'MARIA GUADALUPE', 'CRUZ PERALTA', 'CRUZ SORNOSA JORGE', 'PERALTA VALENZA MARIA INES', '994883652'),
('62541005', 'MHIREYYA SARAI', 'RIOS GARAY', 'RIOS RIOS EDGARD', 'GARAY VEGA KATYA', '994789631'),
('62541063', 'LUZCELY', 'SOLORZANO FLORIDO', 'SOLORSANO BUENDIA MARIO', 'FLORIDO UTANI JUANITA', '978549604'),
('62560849', 'JADE NAHOMI', 'LEON TAIPE', 'LEON CRUZ OSCAR', 'TAIPE ESPINOZA DINA', '973647572'),
('62694835', 'DAYRO ANTHONY', 'CERVANTES RAMOS', 'CERVANTES VELASQUEZ JULIO CESAR', 'RAMOS MIRANDA DORIS', '938421989'),
('62800897', 'XIADANI CAMILA', 'PEREIRA VIVANCO', 'PEREIRA SAAVEDRA MIGUEL ANGEL', 'VIVANCO FERNANDEZ VANESSA', '978293033'),
('63031698', 'CHASKA PILAR', 'JURO VERMEJO', 'JURO VILLEGAS OLJERD', 'VERMEJO MARTINEZ PATRICIA', '949624053'),
('63031702', 'ALESSIA', 'MARCILLA TORRES', 'MARCILLA ALARCON DARWIN', 'TORRES ARANDO KATYA', '990300673'),
('63259458', 'PAUL FABRICIO', 'MOREANO ACRA', 'MOREANO COLLANZA BENICIO', 'ACRA SUBELETE RUJINA', '987304684'),
('63289657', 'BRIYITTE ANDREA', 'TICA RETAMOZO', 'TICA ALENDEZ KINDER GARDEN', 'RETAMOZO SALINAS EDUVIGES EVA', '974234188'),
('63773239', 'ARIANA YIDA', 'SAYAGO MENACHO', 'SAYAGO ZEGARRA LUCHO FELIPE', 'MENACHO MOSCOSO MARIA MAGDALENA', NULL),
('74167832', 'NAHELY ALANIZ', 'ESPINOZA COLCA', 'ESPINOZA CARON FEDERICO', 'COLCA OLIVARES PAULINA', NULL),
('74263821', 'DAYIRO', 'ARCOS TINTAYA', 'ARCOS MANSILLA ROTMER', 'TINTAYA CARBAJAL MARILU', '941091063'),
('77628961', 'DELLY MADAI', 'FALCON ALLCA', 'FALCON SALAZAR BENJAMIN', 'ALLCA HERBAY DELIA', '994459915'),
('78060077', 'CHRISTOFER JOSE', 'AGUILAR FLORES', 'AGUILAR HUISA CHISTHIAN', 'FLORES ZEGARRA BRIYET', '932953182'),
('78120675', 'SUMAQ TIKA', 'SIERRA SALAS', 'SIERRA OVALLE GILBERT', 'SALAS LUPA MARTA', '983644999'),
('78122317', 'ALBA YULIET', 'YUCA PACOMPIA', 'YUCA SARAYA ULISES DOMINGO', 'PACOMPIA MORIANO JENNY', '997487290'),
('78162177', 'LIZ ARIANA', 'TICA RETAMOZO', 'TICA ALENDEZ KINDER GARTEN', 'RETAMOZO SALINAS EDUVIGES EVA', '974134188'),
('78239268', 'ADRIANO ARISTIDES', 'MEZA SOLIS', 'MEZA FELIX TINO ARISTIDIS', 'SOLIS SERRANO YOVANNA', '983785846'),
('78501279', 'LUIS ADRIANO', 'VILLEGAS PEÑA', 'VILLEGAS COSIO CHISTIAN LUIS', 'PEÑA SAMANIEGO ANGIE', '980560374'),
('78581006', 'JOSE ADRIANO', 'VITOR ARTEAGA', 'VICTOR RETAMOSO JOSE LUIS', 'ARTEAGA PUMAPILLO YANET', '976713026'),
('78612360', 'JUAN DIEGO', 'VIZA DEL CASTILLO MAXIMO', 'VIZA ASTURIAS JUSTO JUAN', 'DEL CASTILLO CONDORPUSA ANA SOFIA', '969500784'),
('78640648', 'THIAGO GAHEL', 'TRUJILLO MONTESINOS', 'TRUJILLO SOTO JOSE LUIS', 'MONTESINOS TUMBA INGRID YAJAIRA', '961216823'),
('78765447', 'DHIVYHE JAHYNE', 'NIEBLES HUALLPA', 'NIEBLES ROMUHO DHEYVI', 'HUALLPA AYMARA VICTORIA', '928645796'),
('78782797', 'ZIAM JOSE', 'DELZO CARRASCO', 'DELZO DELAO JOSE LUIS', 'CARRASCO ROMAN MARLENI', '983679986'),
('78833191', 'ABYAL YABETH', 'SAUÑE INGA', 'SAUÑE HUACHO ABEL', 'INGA CAHUANA ALEJANDRA', '958005577'),
('78851722', 'KIMBERLY LUCIANA', 'ABANTO PEÑA', 'ABANTO CANALES JOSE LUIS', 'PEÑA ESPINOZA MARIA VERONICA', '935627765'),
('78875614', 'THIAGO JOSHUA', 'GIL ROBLES', 'GIL SANCHEZ EDWIN', 'ROBLES CONTRERAS ERIKA CYNTHIA', '932212873'),
('78921039', 'BIANKA ABIGAIL', 'TANTA URUCUTIPA', 'TANTA GARCIA NELSON', 'URUCUTIPA APAZA VIVIANA', '986144389'),
('78955412', 'YARETSI ABIGAIL', 'SALAS ALVITES', 'SALAS PALACIOS FABIO', 'ALVITES CASAJIANCA EVELIN', NULL),
('78957467', 'SAERON EMILSON', 'VEGA QUISPE', 'VEGA CABRERA EMILSON', 'QUISPE YANA SADITH', '949757766'),
('78971375', 'ARIANA', 'LEON BARRIENTOS', 'LEON CRUZ JOSUE', 'BARRIENTOS TALAVERANO AIDA', '983604962'),
('79002953', 'ADRIANA MITZI', 'AGUILAR FLORES', 'AGUILAR HUISA CRISTIAN', 'FLORES ZEGARRA BRIGUIT', '932953182'),
('79146797', 'ITZEL ARIADNE', 'ABARCA PEREZ', 'ABARCA PORTILLO JULIO CESAR', 'PEREZ HERRERA KAREN', NULL),
('79177545', 'SAMIA ELENA', 'TELLO BRAÑES', 'TELLO SARMIENTO JHERMAN BILL', 'BRAÑES CHIPANA ZHENIA YANIRA', '948065711'),
('81047203', 'NEYMAR GIANNI', 'HUAMAN ANTEZANA', 'HUAMAN MUÑOZ ORLANDO', 'ANTEZANA VARGAS LORENZA', '983607896'),
('81080860', 'KHAROLL SMITH', 'CARDENAS UTANI', 'CARDENAS INCA ROSENDO', 'UTANI SUEL MARTHA', '961503020'),
('81080901', 'KEID LUANA', 'SAAVEDRA PEREZ', 'SAAVEDRA CONDORI DAVID EDGAR', 'PERREZ CERRO KHATERINE SUSAN', '982519120'),
('81676363', 'MARCELO', 'SOMOCURCIO HUALLPA', 'SOMOCURCIO MARTINEZ HECTOR', 'HUALLPA GARRAMA AYDE', '940085732');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturacion`
--

CREATE TABLE `facturacion` (
  `id_facturacion` int(11) NOT NULL,
  `tipo_facturacion` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `facturacion`
--

INSERT INTO `facturacion` (`id_facturacion`, `tipo_facturacion`) VALUES
(1, 'Recibo'),
(2, 'Boleta');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libroegresos`
--

CREATE TABLE `libroegresos` (
  `id_libroegresos` int(11) NOT NULL,
  `dni_personal` varchar(8) NOT NULL,
  `monto_disponible` double NOT NULL,
  `monto_egreso` double NOT NULL,
  `fecha` date NOT NULL,
  `concepto_de` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `libroegresos`
--

INSERT INTO `libroegresos` (`id_libroegresos`, `dni_personal`, `monto_disponible`, `monto_egreso`, `fecha`, `concepto_de`) VALUES
(1, '45645645', 1200, 20, '2018-04-19', 'COMPRA DE PAPEL A4');

--
-- Disparadores `libroegresos`
--
DELIMITER $$
CREATE TRIGGER `deleteLibroEgresos` AFTER DELETE ON `libroegresos` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible+old.monto_egreso
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertLibroEgresos` AFTER INSERT ON `libroegresos` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible-new.monto_egreso
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateEgreso` AFTER UPDATE ON `libroegresos` FOR EACH ROW IF new.monto_egreso>old.monto_egreso THEN
	UPDATE saldo_actual
    SET monto_disponible=monto_disponible-(new.monto_egreso-old.monto_egreso);
ELSE
	UPDATE saldo_actual
    SET monto_disponible=monto_disponible+(old.monto_egreso-new.monto_egreso);
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `matricula`
--

CREATE TABLE `matricula` (
  `id_matricula` int(11) NOT NULL,
  `id_facturacion` int(11) NOT NULL,
  `pendiente_matricula` double NOT NULL,
  `dni_estudiante` varchar(8) NOT NULL,
  `grado_estudiante` varchar(50) NOT NULL,
  `dni_personal` varchar(8) NOT NULL,
  `fecha_matricula` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `matricula`
--

INSERT INTO `matricula` (`id_matricula`, `id_facturacion`, `pendiente_matricula`, `dni_estudiante`, `grado_estudiante`, `dni_personal`, `fecha_matricula`) VALUES
(1, 1, 50, '78833191', '3 Años', '45645645', '2018-01-02'),
(2, 2, 50, '81080860', '5 Años', '45645645', '2018-02-04'),
(3, 1, 50, '62800897', '1° de Primaria', '45645645', '2018-02-12'),
(4, 2, 30, '63259458', '1° de Primaria', '45645645', '2018-02-22'),
(5, 1, 70, '78640648', '3 Años', '45645645', '2018-01-09'),
(6, 1, 0, '79002953', '3 Años', '45645645', '2018-01-10'),
(7, 1, 0, '78060077', '4 Años', '45645645', '2018-01-17'),
(8, 1, 0, '78782797', '3 Años', '54564564', '2018-01-18'),
(9, 1, 0, '78875614', '3 Años', '54564564', '2018-02-01'),
(10, 1, 0, '81047203', '5 Años', '54564564', '2018-02-02'),
(12, 1, 0, '78971375', '5 Años', '54564564', '2018-02-02'),
(13, 1, 0, '62560849', '3° de Primaria', '54564564', '2018-03-02'),
(14, 1, 100, '63031702', '5 Años', '54564564', '2018-03-05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('medrano122174@gmail.com', '$2y$10$lket.Whz7sNhQWNvo/ENKeSG3NuS5J3kVmtWsoqq5HI7CCe38EAOG', '2018-04-08 03:36:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personaldocente`
--

CREATE TABLE `personaldocente` (
  `dni_personal` varchar(8) NOT NULL,
  `nombre_personal` varchar(50) NOT NULL,
  `apellidos_personal` varchar(50) NOT NULL,
  `cargo_personal` varchar(50) NOT NULL,
  `telefono_personal` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `personaldocente`
--

INSERT INTO `personaldocente` (`dni_personal`, `nombre_personal`, `apellidos_personal`, `cargo_personal`, `telefono_personal`) VALUES
('45645645', 'jorge', 'Monzon Pareja', 'Director', '983554678'),
('54564564', 'CARMEN ROSA', 'ALVARES RETAMOSO', 'AUXILIAR DE TRES AÑOS', '945454564'),
('76669414', 'kelvin', 'medrano carrasco', 'practicante', '944124545');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `refrigerio_mensualidad`
--

CREATE TABLE `refrigerio_mensualidad` (
  `id_refmen` int(11) NOT NULL,
  `id_facturacion` int(11) NOT NULL,
  `nro_boleta` varchar(15) NOT NULL,
  `dni_estudiante` varchar(8) NOT NULL,
  `grado_estudiante` varchar(30) NOT NULL,
  `mes` varchar(200) NOT NULL,
  `monto_refmen` double NOT NULL,
  `pendiente_refmen` double NOT NULL,
  `concepto_de` varchar(200) NOT NULL,
  `fecha_refmen` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `refrigerio_mensualidad`
--

INSERT INTO `refrigerio_mensualidad` (`id_refmen`, `id_facturacion`, `nro_boleta`, `dni_estudiante`, `grado_estudiante`, `mes`, `monto_refmen`, `pendiente_refmen`, `concepto_de`, `fecha_refmen`) VALUES
(1, 1, '0012921', '78640648', '4 Años', 'MARZO', 210, 0, 'Pago por Mensualidad del Estudiante', '2018-04-16'),
(2, 1, '5645456', '81080860', '4 Años', 'MARZO', 70, 0, 'Pago por Refrigerio del Estudiante', '2017-12-12'),
(3, 1, '5454654', '81080860', '5 Años', 'MARZO', 200, 10, 'Pago por Mensualidad del Estudiante', '2018-04-24'),
(4, 1, '2564545', '81080860', '5 Años', 'marzo', 70, 0, 'Pago por Refrigerio del Estudiante', '2018-04-24');

--
-- Disparadores `refrigerio_mensualidad`
--
DELIMITER $$
CREATE TRIGGER `deleteRefMen` AFTER DELETE ON `refrigerio_mensualidad` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible-old.monto_refmen
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertRefMen` AFTER INSERT ON `refrigerio_mensualidad` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible+new.monto_refmen
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateRefMen` AFTER UPDATE ON `refrigerio_mensualidad` FOR EACH ROW BEGIN
    IF new.monto_refmen>old.monto_refmen THEN
        UPDATE saldo_actual
        SET monto_disponible=monto_disponible+(new.monto_refmen-old.monto_refmen);       
    ELSE
        UPDATE saldo_actual
        SET monto_disponible=monto_disponible-(old.monto_refmen-new.monto_refmen);

    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `saldo_actual`
--

CREATE TABLE `saldo_actual` (
  `id_saldo` int(11) NOT NULL,
  `monto_disponible` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `saldo_actual`
--

INSERT INTO `saldo_actual` (`id_saldo`, `monto_disponible`) VALUES
(1, 2780);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trasladosinscripciones`
--

CREATE TABLE `trasladosinscripciones` (
  `id_documento` int(11) NOT NULL,
  `id_facturacion` int(11) NOT NULL,
  `nro_recibo` varchar(15) NOT NULL,
  `dni_estudiante` varchar(8) NOT NULL,
  `monto_documento` double NOT NULL,
  `fecha_documento` date NOT NULL,
  `concepto_de` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `trasladosinscripciones`
--

INSERT INTO `trasladosinscripciones` (`id_documento`, `id_facturacion`, `nro_recibo`, `dni_estudiante`, `monto_documento`, `fecha_documento`, `concepto_de`) VALUES
(1, 1, '0012465', '63031702', 50, '2018-01-15', 'Inscripcion de Estudiante'),
(2, 1, '0012009', '78833191', 50, '2017-03-02', 'Inscripcion de Estudiante'),
(3, 1, '0012306', '78971375', 50, '2018-02-05', 'Inscripcion de Estudiante'),
(4, 1, '0012288', '81080860', 50, '2017-12-04', 'Inscripcion de Estudiante'),
(5, 1, '0012317', '62800897', 50, '2017-12-06', 'Inscripcion de Estudiante'),
(6, 1, '0012489', '78782797', 50, '2018-01-26', 'Inscripcion de Estudiante'),
(7, 1, '0012381', '63259458', 0, '2017-12-22', 'Inscripcion de Estudiante'),
(8, 1, '0012400', '81047203', 50, '2017-12-26', 'Inscripcion de Estudiante'),
(9, 1, '0012434', '78875614', 50, '2018-01-05', 'Inscripcion de Estudiante'),
(10, 2, '0012445', '78060077', 50, '2018-01-09', 'Inscripcion de Estudiante'),
(11, 1, '0012509', '79002953', 50, '2018-02-05', 'Inscripcion de Estudiante'),
(12, 1, '0012445', '78640648', 0, '2018-01-09', 'Inscripcion de Estudiante'),
(20, 1, '0012364', '78833191', 50, '2018-03-06', 'Inscripcion de Estudiante'),
(21, 1, '0012356', '62560849', 50, '2018-02-02', 'Inscripcion de Estudiante'),
(22, 1, '0012464', '78851722', 50, '2018-03-02', 'Inscripcion de Estudiante');

--
-- Disparadores `trasladosinscripciones`
--
DELIMITER $$
CREATE TRIGGER `deleteTrasladosInscripciones` AFTER DELETE ON `trasladosinscripciones` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible-old.monto_documento
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertTrasladosInscripciones` AFTER INSERT ON `trasladosinscripciones` FOR EACH ROW UPDATE saldo_actual
set monto_disponible=monto_disponible+new.monto_documento
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateTrasladosInscripciones` AFTER UPDATE ON `trasladosinscripciones` FOR EACH ROW IF new.monto_documento>old.monto_documento THEN
	UPDATE saldo_actual
    SET monto_disponible=monto_disponible+(new.monto_documento-old.monto_documento);
ELSE
	UPDATE saldo_actual
    SET monto_disponible=monto_disponible-(old.monto_documento-new.monto_documento);
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.es', '$2y$10$TQuE40WU3bEg3Qt6HIB4jeTnYOs0YIazr5s4vQyAl1abpt3/Z/fam', 'kMWcO9aolaayRjMruYeJQUWcB2dS35PjZFhZ1xgYtsUMX5fWox1oPwy3AuBk', NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalle_matricula`
--
ALTER TABLE `detalle_matricula`
  ADD PRIMARY KEY (`id_detallematricula`),
  ADD KEY `detalle_matricula_ibfk_1` (`id_matricula`);

--
-- Indices de la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD PRIMARY KEY (`dni_estudiante`);

--
-- Indices de la tabla `facturacion`
--
ALTER TABLE `facturacion`
  ADD PRIMARY KEY (`id_facturacion`);

--
-- Indices de la tabla `libroegresos`
--
ALTER TABLE `libroegresos`
  ADD PRIMARY KEY (`id_libroegresos`),
  ADD KEY `dni_personal` (`dni_personal`);

--
-- Indices de la tabla `matricula`
--
ALTER TABLE `matricula`
  ADD PRIMARY KEY (`id_matricula`),
  ADD KEY `id_facturacion` (`id_facturacion`),
  ADD KEY `dni_estudiante` (`dni_estudiante`),
  ADD KEY `dni_personal` (`dni_personal`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `personaldocente`
--
ALTER TABLE `personaldocente`
  ADD PRIMARY KEY (`dni_personal`);

--
-- Indices de la tabla `refrigerio_mensualidad`
--
ALTER TABLE `refrigerio_mensualidad`
  ADD PRIMARY KEY (`id_refmen`),
  ADD KEY `id_facturacion` (`id_facturacion`),
  ADD KEY `dni_estudiante` (`dni_estudiante`);

--
-- Indices de la tabla `saldo_actual`
--
ALTER TABLE `saldo_actual`
  ADD PRIMARY KEY (`id_saldo`);

--
-- Indices de la tabla `trasladosinscripciones`
--
ALTER TABLE `trasladosinscripciones`
  ADD PRIMARY KEY (`id_documento`),
  ADD KEY `id_facturacion` (`id_facturacion`),
  ADD KEY `dni_estudiante` (`dni_estudiante`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle_matricula`
--
ALTER TABLE `detalle_matricula`
  MODIFY `id_detallematricula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `facturacion`
--
ALTER TABLE `facturacion`
  MODIFY `id_facturacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `libroegresos`
--
ALTER TABLE `libroegresos`
  MODIFY `id_libroegresos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `matricula`
--
ALTER TABLE `matricula`
  MODIFY `id_matricula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `refrigerio_mensualidad`
--
ALTER TABLE `refrigerio_mensualidad`
  MODIFY `id_refmen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `saldo_actual`
--
ALTER TABLE `saldo_actual`
  MODIFY `id_saldo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `trasladosinscripciones`
--
ALTER TABLE `trasladosinscripciones`
  MODIFY `id_documento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_matricula`
--
ALTER TABLE `detalle_matricula`
  ADD CONSTRAINT `detalle_matricula_ibfk_1` FOREIGN KEY (`id_matricula`) REFERENCES `matricula` (`id_matricula`);

--
-- Filtros para la tabla `libroegresos`
--
ALTER TABLE `libroegresos`
  ADD CONSTRAINT `dni_personal_ibfk_1` FOREIGN KEY (`dni_personal`) REFERENCES `personaldocente` (`dni_personal`);

--
-- Filtros para la tabla `matricula`
--
ALTER TABLE `matricula`
  ADD CONSTRAINT `matricula_ibfk_1` FOREIGN KEY (`id_facturacion`) REFERENCES `facturacion` (`id_facturacion`),
  ADD CONSTRAINT `matricula_ibfk_2` FOREIGN KEY (`dni_estudiante`) REFERENCES `estudiante` (`dni_estudiante`),
  ADD CONSTRAINT `matricula_ibfk_3` FOREIGN KEY (`dni_personal`) REFERENCES `personaldocente` (`dni_personal`);

--
-- Filtros para la tabla `refrigerio_mensualidad`
--
ALTER TABLE `refrigerio_mensualidad`
  ADD CONSTRAINT `refrigerio_mensualidad_ibfk_1` FOREIGN KEY (`id_facturacion`) REFERENCES `facturacion` (`id_facturacion`),
  ADD CONSTRAINT `refrigerio_mensualidad_ibfk_2` FOREIGN KEY (`dni_estudiante`) REFERENCES `estudiante` (`dni_estudiante`);

--
-- Filtros para la tabla `trasladosinscripciones`
--
ALTER TABLE `trasladosinscripciones`
  ADD CONSTRAINT `trasladosinscripciones_ibfk_1` FOREIGN KEY (`id_facturacion`) REFERENCES `facturacion` (`id_facturacion`),
  ADD CONSTRAINT `trasladosinscripciones_ibfk_2` FOREIGN KEY (`dni_estudiante`) REFERENCES `estudiante` (`dni_estudiante`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
