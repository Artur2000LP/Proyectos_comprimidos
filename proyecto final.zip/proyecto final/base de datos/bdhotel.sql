-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-10-2022 a las 02:16:17
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdhotel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `talquiler`
--

CREATE TABLE `talquiler` (
  `idAlquiler` int(11) NOT NULL,
  `precio` int(11) DEFAULT NULL,
  `fechaEntrada` date DEFAULT NULL,
  `fechaSalida` date DEFAULT NULL,
  `estado` char(1) DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  `fkVendedor` int(11) DEFAULT NULL,
  `fkCliente` int(11) DEFAULT NULL,
  `fkHabitacion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `talquiler`
--

INSERT INTO `talquiler` (`idAlquiler`, `precio`, `fechaEntrada`, `fechaSalida`, `estado`, `observacion`, `fkVendedor`, `fkCliente`, `fkHabitacion`) VALUES
(1, 123, '2022-09-01', '2022-09-02', 'l', 'ninguna', NULL, NULL, NULL),
(2, 36, '2022-10-05', '2022-10-06', 'l', 'ninguna', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tcliente`
--

CREATE TABLE `tcliente` (
  `idCliente` int(11) NOT NULL,
  `documento` varchar(8) DEFAULT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `lugarNacimiento` varchar(40) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `observacion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tcliente`
--

INSERT INTO `tcliente` (`idCliente`, `documento`, `nombre`, `fechaNacimiento`, `lugarNacimiento`, `sexo`, `observacion`) VALUES
(1, '76090321', 'suker', '2022-09-06', 'abancay', 'M', 'docente'),
(2, '77485623', 'fernando ', '2002-10-02', 'abancay', 'M', 'estudiante '),
(3, '74757874', 'marco', '1998-02-17', 'cusco', 'M', 'nada'),
(4, '71112123', 'jorge', '2022-09-07', 'abancay', 'M', 'ninguna'),
(5, '77794565', 'leo ', '2022-10-18', 'abancay', 'M', 'ninguna'),
(6, '71724123', 'luis', '2022-10-03', 'abancay', 'M', 'ninguna');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `thabitacion`
--

CREATE TABLE `thabitacion` (
  `IdHabitacion` int(11) NOT NULL,
  `numeroCamas` int(11) DEFAULT NULL,
  `descripcion` varchar(40) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL,
  `fkTipo` int(11) DEFAULT NULL,
  `observacion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `thabitacion`
--

INSERT INTO `thabitacion` (`IdHabitacion`, `numeroCamas`, `descripcion`, `precio`, `fkTipo`, `observacion`) VALUES
(1, 3, 'amplia', 35, NULL, 'ninguna'),
(2, 3, 'amplia', 35, NULL, 'ninguna'),
(3, 3, 'amplia', 35, NULL, 'ninguna');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ttipo`
--

CREATE TABLE `ttipo` (
  `idTipo` int(11) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tvendedor`
--

CREATE TABLE `tvendedor` (
  `idVendedor` int(11) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `direccion` varchar(40) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  `sueldo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tvendedor`
--

INSERT INTO `tvendedor` (`idVendedor`, `nombre`, `direccion`, `telefono`, `observacion`, `sueldo`) VALUES
(1, 'suker', 'abancay', '995955654', 'ninguna', 51);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `talquiler`
--
ALTER TABLE `talquiler`
  ADD PRIMARY KEY (`idAlquiler`),
  ADD KEY `fkHabitacion` (`fkHabitacion`),
  ADD KEY `fkCliente` (`fkCliente`),
  ADD KEY `fkVendedor` (`fkVendedor`);

--
-- Indices de la tabla `tcliente`
--
ALTER TABLE `tcliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indices de la tabla `thabitacion`
--
ALTER TABLE `thabitacion`
  ADD PRIMARY KEY (`IdHabitacion`),
  ADD KEY `fkTipo` (`fkTipo`);

--
-- Indices de la tabla `ttipo`
--
ALTER TABLE `ttipo`
  ADD PRIMARY KEY (`idTipo`);

--
-- Indices de la tabla `tvendedor`
--
ALTER TABLE `tvendedor`
  ADD PRIMARY KEY (`idVendedor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `talquiler`
--
ALTER TABLE `talquiler`
  MODIFY `idAlquiler` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tcliente`
--
ALTER TABLE `tcliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `thabitacion`
--
ALTER TABLE `thabitacion`
  MODIFY `IdHabitacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ttipo`
--
ALTER TABLE `ttipo`
  MODIFY `idTipo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tvendedor`
--
ALTER TABLE `tvendedor`
  MODIFY `idVendedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `talquiler`
--
ALTER TABLE `talquiler`
  ADD CONSTRAINT `talquiler_ibfk_1` FOREIGN KEY (`fkHabitacion`) REFERENCES `thabitacion` (`IdHabitacion`),
  ADD CONSTRAINT `talquiler_ibfk_2` FOREIGN KEY (`fkCliente`) REFERENCES `tcliente` (`idCliente`),
  ADD CONSTRAINT `talquiler_ibfk_3` FOREIGN KEY (`fkVendedor`) REFERENCES `tvendedor` (`idVendedor`);

--
-- Filtros para la tabla `thabitacion`
--
ALTER TABLE `thabitacion`
  ADD CONSTRAINT `thabitacion_ibfk_1` FOREIGN KEY (`fkTipo`) REFERENCES `ttipo` (`idTipo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
