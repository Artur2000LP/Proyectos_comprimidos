<?php
$conexion1 = mysqli_connect("localhost", "root", "", "web_rentcar");
