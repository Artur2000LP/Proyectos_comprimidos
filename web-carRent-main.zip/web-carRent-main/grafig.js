$(document).ready(function () {
  let GETauto1 = 1;
  let auto1 = GETauto1 + "0%";
  let GETauto2 = 1;
  let auto2 = GETauto1 + "0%";
  let GETauto3 = 1;
  let auto3 = GETauto1 + "0%";
  let GETauto4 = 1;
  let auto4 = GETauto1 + "0%";
  let GETauto5 = 1;
  let auto5 = GETauto1 + "0%";
  let GETauto6 = 1;
  let auto6 = GETauto1 + "0%";

  $(".adobe").css("width", auto1);
  $(".html").css("width", auto2);
  $(".css").css("width", auto3);
  $(".lesssass").css("width", auto4);
  $(".jquery").css("width", auto5);
  $(".javascript").css("width", auto6);
});
