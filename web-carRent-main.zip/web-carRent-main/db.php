<?php
$conexion=mysqli_connect("localhost","root","","web_rentcar")or die(
    "error de conexion");
?>