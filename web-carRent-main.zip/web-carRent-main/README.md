<<<<<<< HEAD
# 🚘 Responsive Car website

# referenias code wen Car https://www.youtube.com/watch?v=bDngcOQ8Img&t=7557s

# repositorio https://www.youtube.com/watch?v=bDngcOQ8Img&t=7557s

# repositorio Fonts: https://fonts.google.com/

# Swiper: https://swiperjs.com/

# repositorio https://www.youtube.com/watch?v=bDngcOQ8Img&t=7557s

# repositorio https://www.youtube.com/watch?v=bDngcOQ8Img&t=7557s

#autos actuales
#1
Cadillac
XT4
#2
Alfa Romeo
Giulia
#3
Acura
TLX
#4
Jeep
Wrangler
#5
Chevrover
Colorado

<!--  -->
<!--  -->
<!--  -->

#6
Volvo
XC40
#7
Gmc
Yukon
#8
Mitshubishi
Outlander
#8
Chrylers
Pacifica
=======
lucho carlos checcaña alejandro.

Arturo letona porras
>>>>>>> 6d70517018d9c141f5af03514135d5d14a772e26
